from .sorn import Simulator, Trainer
import logging
from .utils import *

__author__ = "Saranraj Nambusubramaniyan"
__version__ = "0.6.2"

logging.basicConfig(level=logging.INFO)
